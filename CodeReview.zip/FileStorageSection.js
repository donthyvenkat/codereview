import React, { useContext } from 'react';
import { Dropdown, DropdownSkeleton } from '@console/pal/carbon-components-react';  
// documentation at https://react.carbondesignsystem.com/
import { SelectionsContext } from './Context';


export const FileStorageSection = () => {
  /* fsAllItems from context looks like this:
  fsAllItems: [
    {
      storageSizeOptions: [
        { size, text } 
      ]
      AvailableSnapshotSizes: [
        {
          size
          text
          baremetalServerRestrictions: [
            id
          ]
        }
      ]
    }
  ] */

  const {
    fsAllItems,
    selectedBaremetal,
    selectedFileStorageSize,
    setSelectedFileStorageSize,
    selectedFileStorageSnapshotSize,
    setSelectedFileStorageSnapshotSize,
  } = useContext(SelectionsContext);

  const findIt = () => {
    for (let i = 0; i < fsAllItems.length; i++) {
      if ( fsAllitems[i].size == selectedFileStorageSize)
        return fsAllitems[i];
    }
    return undefined;
  }

  const isAllowedSnapshotSizeForBaremetal = (snapshotSize, baremetalId) => {
    // search the data structure for the correct storage item, its correct snapshot, and check its ok for the selected baremetal
    let allowed = true;
    for (let i = 0; i < fsAllItems.length; i++) {
      if ( fsAllitems[i].size == selectedFileStorageSize) {
        for(let j = 0; j < fsAllItems[i].AvailableSnapshotSizes.length; j++) {
          if ( fsAllItems[i].AvailableSnapshotSizes[j] == selectedFileStorageSnapshotSize) {
            for (let k = 0; k < fsAllItems[i].AvailableSnapshotSizes[j].baremetalServerRestrictions.length; k++) {
              if ( fsAllItems[i].AvailableSnapshotSizes[j].baremetalServerRestrictions[k].id == baremetalId)
                console.log ('NOT ALLOWED');
                allowed = false;
            }
          }
        }
      }
    }
    return allowed;
  };

  // get available snapshot items for the selected storage size that are allowed for selected baremetal
  const getSnapshotItemsForSelectedStorageSize = (baremetalId) => {
    for (let i = 0; i < fsAllItems.length; i++) {
      if ( fsAllitems[i].size == selectedFileStorageSize) {
        if (isAllowedSnapshotSizeForBaremetal(fsAllitems[i].size, baremetalId)) {
          return fsAllitems[i].AvailableSnapshotSizes;
        }
      }
    }
  }

  // renders the skeleton
  const renderSkeleton = () => {
    return (
      <>
        <div className='storage-input'>
          <legend data-testid="storageSizeSkeleton" className="bx--label">
            Size
          </legend>
          <DropdownSkeleton />  
        </div>
        <div className={c('storage-input')}>
          <legend data-testid="snapshotSkeleton" className="bx--label">
            Snapshot Space
          </legend>
          <DropdownSkeleton />
        </div>
        <div className='storage-input'>
          <legend className="bx--label">IOPS Tier</legend>
          <div className='iopsTierLevelValue'> 4 Iops </div>
        </div>
      </>
    );
  };

  const renderComponent = () => {
    return (
      <>
        <div className='storage-input'>
          <Dropdown
            key="fdsa"
            id="fileStorageSize"
            items={fsAllItems.storageSizeOptions}
            itemToString={(item) => (item ? item.text : '')}
            label='Size'
            selectedItem={selectedFileStorageSize}
            titleText='Size'
            onChange={(evt) => {
              setSelectedFileStorageSize(evt.selectedItem);
              if (parseInt(selectedFileStorageSnapshotSize.size, 10) > evt.selectedItem.id) {
                // reset snapshot since new storage size is way under current size.
                setSelectedFileStorageSnapshotSize(fsAllItems.AvailableSnapshotSizes[0].size);
              }
            }}
            required
          />
        </div>
        <div className='storage-input'>
          <Dropdown
            key="asdf"
            id="snapshot-size"
            items={getSnapshotItemsForSelectedStorageSize(selectedBaremetal.id)}
            itemToString={(item) => (item ? item.capacity + ' GB': '')}
            label=""
            selectedItem={selectedFileStorageSnapshotSize}
            titleText='SnapshotSpace'
            onChange={(evt) => {
              setSelectedFileStorageSnapshotSize(evt.selectedItem.size);
            }}
            required
          />
        </div>
        <div className='storage-input'>
          <legend className="bx--label">Iops Tier</legend>
          <div className='iopsTierLevelValue'> 4 Iops</div>
        </div>
      </>
    );
  };


  // if we have don't have data loaded, render skeleton
  const fsControls = !fsAllItems?.storageSizeOptions ? renderSkeleton() : renderComponent();
  return (
    <div className='section-wrapper'>
      <h4>File Storage</h4>
      <div className='content'>{fsControls}</div>
    </div>
  );
};


FileStorageSection.propTypes = {};
export default FileStorageSection;