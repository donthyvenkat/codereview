import React, { useEffect, useState } from 'react';
import { PageHeader } from '@console/pal/Components';
import { InlineNotification, Tabs, Tab } from '@console/pal/carbon-components-react';
// documentation at https://react.carbondesignsystem.com/


// Order Form Components
import Reqs from './WorkloadRequirements/Reqs';
import BaremetalConfigSection from './BaremetalConfigSection';
import FileStorageSection from './FileStorageSection';
import MySummarySection from './MySummarySection';
import AboutCloudOrderSection from './AboutCloudOrderSection';
import URLS from '../../constants/ui-urls';


import { SelectionsContextProvider } from './Context';
import SvgCloud from '../utils/SvgCloud';
import { whenAccountReady } from '../utils/whenAccountReady';


export const CloudOrderForm = () => {
  const [isAccountReady, setAccountReady] = useState(false);
  const anonymousUser = window.unauthenticated === 'true';


  const accountreadycallback = () => {
    setAccountReady(true);
  };


  useEffect(() => {
    // header component upstream will call this callback when account is ready
    whenAccountReady(accountreadycallback);
  }, [isAccountReady]);


  const renderTabs = () => {
    return (
      <Tabs className='tabContainer' role="navigation" type="container">
        {!anonymousUser && (
          <Tab
            className='tab1'
            role="presentation"
            label="Create"
          >
            <div className='createFormContent'>
              <Reqs />
              <BaremetalConfigSection />
              <FileStorageSection />
            </div>
          </Tab>
        )}
        <Tab
          className='aboutTab'
          role="presentation"
          label="About"
        >
          <div className='aboutFormContent section-wrapper'>
            <AboutCloudOrderSection />
          </div>
        </Tab>
      </Tabs>
    );
  };


  // SelectionsContextProvider is react context provider that stores user inputs for the form component
  return ( // only once the user account data is retrieved (isAccountReady), should we proceed to load the context and build the page
    isAccountReady && ( 
      <div className='myForm'>
        <div className='container'>
          <SelectionsContextProvider>
            <PageHeader
              icon={<SvgCloud />}
              title="Cloud Order Form"
              isProvisioning
              breadcrumbs={[{ href: URLS.CATALOG_COMPUTE_LINK, value: 'Catalog' }]}
            />
            {renderTabs()}
            <div className='summary'>
              <MySummarySection />
            </div>
          </SelectionsContextProvider>
        </div>
      </div>
    )
  );
};


CloudOrderForm.propTypes = {};
export default CloudOrderForm;